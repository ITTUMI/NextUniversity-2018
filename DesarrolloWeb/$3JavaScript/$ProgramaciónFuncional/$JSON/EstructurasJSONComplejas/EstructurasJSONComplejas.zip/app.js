var Estructura = {
  "personas": [
    {
      "Nombre": "Mateo",
      "Edad": 24,
      "Direccion": "Jose Chavez Morado",
      "Teléfono": "5547339005",
      "Estudios": [
        "Escuela Primaria": {
          "Lugar": "ITESM Campus Toluca",
          "Fecha": "2009-2015",
        }
        "Escuela Secundaria": {
          "Lugar": "ITESM Campus Toluca",
          "Fecha": "2015-2018",
        }
      ]
    },
    {
      "Nombre": "Adham",
      "Edad": 25,
      "Direccion": "Providencia Caceres",
      "Teléfono": "5547339005",
      "Estudios":[
        "Escuela Primaria":{
          "Lugar": "ITESM Campus Queretaro",
          "Fecha": "2009 - 2015",
        }
        "Escuela Secundaria":{
          "Lugar": "ITESM Campus Cancun",
          "Fecha": "2015 - 2018",
        }
      ]
    }
  ]
}

var persona1 = Estructura.personas[0];
var persona2 = Estructura.personas[1];
